package com.adapty.onlineshopping.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adapty.onlineshopping.Entities.Cart;
import com.adapty.onlineshopping.Entities.Product;
import com.adapty.onlineshopping.Entities.STATUS;
import com.adapty.onlineshopping.Repository.CartRepository;
import com.adapty.onlineshopping.Repository.ProductRepository;

@Service
public class CartImpl  implements CartInterface {
    @Autowired
    CartRepository CrepoObj;
    @Autowired
    ProductRepository repoObj;

    public List<Cart>fetchAllProducts(){
        return CrepoObj.findAll();

    }
    
    public Optional<Cart> fetchByCartItemId(String cartItemId){
        return CrepoObj.findById(cartItemId);
    }

    public String addTocart(Cart cartObj){
        Optional<Product> obj = repoObj.findById(cartObj.getProductId());
        if(obj.isPresent()){
        if(obj.get().getProductStatus()==STATUS.ACTIVE){
            CrepoObj.save(cartObj);
            return "Added Successfully";
        }
        else{
            return "Not Found";
    }
        }else{
            return " Product unavailable";
        }
      
    }
    public String deleteByCartId(String id){
        CrepoObj.deleteById(id);
          return "Object deleted";
    }
    

    public Cart updateByCartId(Cart cartObj){
        if (cartObj.getCartItemId()==null){
            return null;
        }
        else{
            Optional<Cart> p1=CrepoObj.findById(cartObj.getCartItemId());
            p1.get().setCartItemQty(cartObj.getCartItemQty());
            p1.get().setProductId(cartObj.getProductId());

            CrepoObj.deleteById(cartObj.getCartItemId());
            CrepoObj.save(p1.get());
            return cartObj;
        }

    }
       

    public String deleteItemByProductId(String productId){
        CrepoObj.deleteByProductId(productId);
        //return cartRepo.deleteByProductId(repoObj.deleteById(id);
        return "deleted";
    }
    
    // public float totalByProductPrice(Product productObj,Cart cartObj){
    //     Optional<Product> p1=repoObj.findById(productObj.getProductId());
    //     Optional<Cart> p2=CrepoObj.findById(cartObj.cartItemId);
    //     if(p1.isPresent()){
    //         float sum=0.0f;
    //        List<Product> ans=(List<Product>) p1.get();
    //         List<Cart> ans2=(List<Cart>) p2.get();
    //         for (Product product : ans,ans2) {
                
    //             sum=sum+product.getProductPrice()*p2.getCartItemQty();
    //         }
    //     }

    // }


    


    

    

    


}
