package com.adapty.onlineshopping.Entities;

public enum CATEGORIES{
    CLOTHS,
    ELECTRONICS,
    FOODPRODUCT,
    BOOKS,
    TOYS,
    MOBILES
}

