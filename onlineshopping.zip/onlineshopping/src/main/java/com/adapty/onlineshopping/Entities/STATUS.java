package com.adapty.onlineshopping.Entities;

public enum STATUS {
    ACTIVE,
    INACTIVE
}

